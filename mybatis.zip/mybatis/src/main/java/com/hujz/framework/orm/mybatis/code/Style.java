package com.hujz.framework.orm.mybatis.code;

/**
 * 字段转换方式
 */
public enum Style {
    normal,     //原值
    camelhump,  //驼峰转下划线
    uppercase,  //转换为大写
    lowercase   //转换为小写
}
